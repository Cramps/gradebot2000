import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/**
 * This assignment should receive 100% of the grade when using the example test cases provided.
 * @author Alice Goodgrade
 */
public class ExampleHw {

	public final Integer[] arr;
	
	// Cannot test private attributes from the test class due to visibility.
	private final char untestedField = 'u';
	
	public ExampleHw(Integer[] arr) {
		this.arr = arr;
	}
	
	/**
	 * @return a sorted version of the array
	 */
	public Integer[] getSortedArray() {
		return untestedSortingMethod(arr);
	}
	
	/**
	 * @return true if sorted ascendingly
	 */
	public boolean isSorted() {
		for(int i=1; i < arr.length; i++) {
			if(arr[i] < arr[i-1])
				 return false;
		}
		return true;
	}
	
	/**
	 *  This method takes user input and verification requires reading the console output.
	 *	Check ExampleHwTestCases.testMain() to see how to test with console input and output.
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Enter a number... ");
		int n = inputReader.nextInt();
		inputReader.close();
		System.out.println("Your number is " + String.valueOf(n));
	}
	
	/**
	 *  Cannot test private methods from the test class due to visibility.
	 * @param arr the array to be sorted
	 * @return sorted version of the array
	 */
	private Integer[] untestedSortingMethod(Integer[] arr) {
		ArrayList<Integer> a = new ArrayList<>(Arrays.asList(arr));
		a.sort(Comparator.naturalOrder());
		return a.toArray(arr);
	}

}
